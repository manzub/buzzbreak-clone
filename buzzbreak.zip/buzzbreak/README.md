# newzz.com
My First Python Startup
