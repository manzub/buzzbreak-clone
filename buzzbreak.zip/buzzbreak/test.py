
# from sqlalchemy import create_engine
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from sqlalchemy.sql.sqltypes import DateTime
from sqlalchemy import Column,String,Text,Integer,ForeignKey,UniqueConstraint
from sqlalchemy.orm import relationship,backref
from werkzeug.security import generate_password_hash,check_password_hash
from flask_login import UserMixin



app = Flask(__name__)
app.config['SECRET_KEY'] = 'sampleappp2'
# app.config['SQLALCHEMY_DATABASE_URI'] = "postgresql://doadmin:tf1gvd1jlvara0ow@newzzcom-db-do-user-8043638-0.b.db.ondigitalocean.com:25060/defaultdb?sslmode=require"
app.config['SQLALCHEMY_DATABASE_URI'] = "postgresql://wisdom:Wisdom1Okon@157.230.53.236:5432/wisdom?sslmode=require"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


a_file = open('config/accounts.txt','r+')
c_file = open('config/cashouts.txt','r+')
p_file = open('config/payopts.txt','r+')
r_file = open('config/refs.txt','r+')
t_file = open('config/tokens.txt','r+')
tr_file = open('config/transactions.txt','r+')
u_file = open('config/users.txt','r+')

class User(db.Model,UserMixin):
    __tablename__ = "users"
    id = Column(Integer,primary_key=True)
    email = Column(Text,unique=True)
    password = Column(Text)
    account = relationship('Accounts',backref='users',lazy=True,cascade="all, delete-orphan")
    payopt = relationship('PayOpt',backref='users',lazy=True,cascade="all, delete-orphan")
    transactions = relationship('Transactions',backref='users',lazy=True,cascade="all, delete-orphan")

    def __init__(self,email,password):
        self.email = email
        self.password = generate_password_hash(password)
        self.status = None

    def check_password(self,password):
        return check_password_hash(self.password,password)

class Accounts(db.Model,UserMixin):
    __tablename__ = "accounts"
    id = Column(Integer,primary_key=True)
    balance = Column(String)
    t_balance = Column(String)
    user_id = Column(Integer, ForeignKey('users.id'))

    def __init__(self,balance,t_balance,user_id):
        self.balance = balance
        self.t_balance = t_balance
        self.user_id = user_id

class PayOpt(db.Model,UserMixin):
    __tablename__ = 'payopts'
    id = Column(Integer,primary_key=True)
    type = Column(Integer)
    payment_email = Column(String)
    extras = Column(Text)
    user_id = Column(Integer, ForeignKey('users.id'))

    def __init__(self,type,payment_email,user_id,extras):
        self.type = type
        self.payment_email = payment_email
        self.user_id = user_id
        self.extras = extras

class Transactions(db.Model,UserMixin):
    __tablename__ = 'transactions'
    id = Column(Integer,primary_key=True)
    user_id = Column(Integer,ForeignKey('users.id'))
    alert = Column(Text)
    extras = Column(String(100))

    def __init__(self,alert,extras,user_id):
        self.alert = alert
        self.user_id = user_id
        self.extras = extras

class Cashouts(db.Model,UserMixin):
    __tablename__ = 'cashouts'
    id = Column(Integer,primary_key=True)
    user_email = Column(String)
    amount = Column(String)
    payout_type = Column(String)

    def __init__(self,user_email,amount,payout_type):
        self.user_email = user_email
        self.amount = amount
        self.payout_type = payout_type

class Tokens(db.Model,UserMixin):
    __tablename__ = 'tokens'
    id = Column(Integer,primary_key=True)
    user_email = Column(String)
    token = Column(Text)
    expires = Column(DateTime,default=datetime.utcnow)

    def __init__(self,user_email,token):
        self.user_email = user_email
        self.token = token

# engine = create_engine("postgresql://doadmin:tf1gvd1jlvara0ow@newzzcom-db-do-user-8043638-0.b.db.ondigitalocean.com:25060/defaultdb?sslmode=require")

# with engine.connect() as conn:
#     accounts = conn.execute('SELECT * FROM accounts')
#     for row in accounts:
#         data = [f'{row.balance}\t',f'{row.t_balance}\t',f'{row.user_id}\n']
#         a_file.writelines(data)

#     cashouts = conn.execute('SELECT * FROM cashouts')
#     for row in cashouts:
#         data = [f'{row.user_email}\t',f'{row.amount}\t',f'{row.payout_type}\n']
#         c_file.writelines(data)

#     payopts = conn.execute('SELECT * FROM payopts')
#     for row in payopts:
#         data = [f'{row.type}\t',f'{row.payment_email}\t',f'{row.extras}\t',f'{row.user_id}\n']
#         p_file.writelines(data)

#     # refs = conn.execute('SELECT * FROM refs')
#     # for row in refs:
#     #     data = [f'{row.ref_id}\t',f'{row.user_email}\n']
#     #     r_file.writelines(data)

#     tokens = conn.execute('SELECT * FROM tokens')
#     for row in tokens:
#         data = [f'{row.user_email}\t',f'{row.token}\t',f'{row.expires}\n']
#         t_file.writelines(data)

#     transactions = conn.execute('SELECT * FROM transactions')
#     for row in transactions:
#         data = [f'{row.user_id}\t',f'{row.alert}\t',f'{row.extras}\n']
#         tr_file.writelines(data)

#     users = conn.execute('SELECT * FROM users')
#     for row in users:
#         data = [f'{row.email}\t',f'{row.password}\n']
#         u_file.writelines(data)
#     pass

# lines = u_file.readlines()
# for line in lines:
#     data = line.split('\t')
#     print(data[1])

users = User.query.all()
for user in users:
    print(user.email)