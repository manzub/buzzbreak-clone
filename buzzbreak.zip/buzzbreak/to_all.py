from buzzbreak import app
from sqlalchemy import create_engine
from flask_mail import Mail, Message
db_string = "postgresql://doadmin:tf1gvd1jlvara0ow@newzzcom-db-do-user-8043638-0.b.db.ondigitalocean.com:25060/defaultdb"
db = create_engine(db_string)
mail = Mail(app)

all_users = db.execute("SELECT * FROM users")
with app.app_context():
    with mail.connect() as conn:
        for user in all_users:
            message = 'Dear user,\n24hours from now, NEWZZ$ will be running a full database migration and we advice all our users to please login now so as to avoid data loss,\n after the data migration we will be awarding our now existing 200 users $1\n so login now to claim this reward.\n  https://newzzdollar.com/login\n'
            subject = 'New Mail From NEWZZ$'
            msg = Message(
                recipients=[user.email],
                body=message,
                subject=subject,
                sender = ('NEWZZ$-AdMIN','no-reply@newzz.com')
                )
            conn.send(msg)
